ojciec(wieslaw,malgorzata).
ojciec(leszek,kamil).
ojciec(leszek,natalia).

matka(malgorzata,kamil).
matka(malgorzata,natalia).

mezczyzna(wieslaw).
mezczyzna(kamil).
mezczyzna(leszek).

kobieta(malgorzata).
kobieta(natalia).

rodzic(leszek,kamil).
rodzic(malgorzata,kamil).
rodzic(leszek,natalia).
rodzic(malgorzata,natalia).
rodzic(wieslaw,malgorzata).

jest_matka(X) :-
	matka(X,_).
jest_ojcem(X) :-
	ojciec(X,_).
jest_synem(X) :-
	mezczyzna(X),
	rodzic(_,X).
dziadek(X,Y) :-
	ojciec(X,Z),
	rodzic(Z,Y).
rodzenstwo(X,Y) :-
	ojciec(Z,X),ojciec(Z,Y),
	X\=Y,
	matka(W,X),matka(W,Y).

siostra(X,Y) :-
	kobieta(X),
	rodzenstwo(X,Y).




