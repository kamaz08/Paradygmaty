on(a1,a2).
on(a2,a3).
on(a3,a4).
on(a4,a5).

above(X,Y) :-
	on(X,Y);(on(X,Z),above(Z,Y)).

kamaz(X,Y):-
	(on(X,_), \+on(Y,_))
	;
	(on(X,Z3), on(Y,Z4),kamaz(Z3,Z4)).
