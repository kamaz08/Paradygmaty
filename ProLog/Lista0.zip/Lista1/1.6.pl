liczby(X,Y,Z) :- between(X,Y,Z),prime(Z),Z>1.
prime(X):- \+ (Z is round(sqrt(abs(X))),(between(2,Z,Y),W is (X mod Y), W=0)).

























