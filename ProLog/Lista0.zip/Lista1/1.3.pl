left_of(hourglass,pencil).
left_of(butterfly,hourglass).
left_of(fish,butterfly).

above(bike, pencil).
above(camera, butterfly).

left(X, Y) :-
	left_of(X, Y);
	(left_of(X, Z),
	left(Z, Y)).

right_of(Object1, Object2) :-
	left(Object2, Object1).

below(Object1, Object2) :-
	above(Object2, Object1).

higher(X, Y) :-
	above(X, Y);
	above(X, Z),
	(left(Z, Y);
	right_of(Z, Y)).

