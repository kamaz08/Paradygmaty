le(1,1). le(1,2). le(1,3). le(1,5). le(1,6). le(1,10). le(1,20). le(1,60).  le(1,120).
le(2,2). le(2,6). le(2,10). le(2,20). le(2,60). le(2,120).
le(3,3). le(3,6). le(3,60). le(3,120).
le(5,5). le(5,10). le(5,20). le(5,60). le(5,120).
le(6,6). le(6,60). le(6,120).
le(10,10). le(10,20). le(10,60). le(10,120).
le(20,20). le(20,60). le(20,120).
le(60,60). le(60,120).
le(120,120).
le(77,77).
le(120,2).

max(X):- le(Y,Y),X\=Y,le(X,Y).
maksymalna(X):- le(X,X), \+max(X).

min(X):- le(Y,Y),X\=Y,le(Y,X).
minimalna(X):- le(X,X), \+min(X).

najm(X):- le(Y,Y),X\=Y,\+le(X,Y).
najmniejsza(X):- le(X,X), \+najm(X).

najw(X):- le(Y,Y),X\=Y,\+le(Y,X).
najwieksza(X):- le(X,X), \+najw(X).

zwrotnosc :- \+ ((le(X, _); le(_, X)), \+ le(X, X)).
przechodniosc:- \+ (le(X,Y),le(Y,Z), \+ le(X,Z)).
slaba_antysymetrycznosc:- \+ (le(X,Y), le(Y,X) , X\=Y).

relacja :- zwrotnosc, przechodniosc, slaba_antysymetrycznosc.


