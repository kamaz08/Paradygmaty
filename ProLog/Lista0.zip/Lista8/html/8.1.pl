:- use_module(library(xpath)).
:- use_module(library(sgml)).


find(D,O):- xpath(D, //a(@href) ,X),
		parse_url(X,'http://localhost/',List),member(host(O),List).

servers(In,L):-load_html(In,D,[]),
	setof(M,find(D,M),L).
