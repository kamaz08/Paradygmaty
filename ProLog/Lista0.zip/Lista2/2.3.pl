arc(a,b).
arc(b,c).
arc(c,d).
arc(b,a).

osiagalny(X,X).
osiagalny(X,Y):-
	osiagalny(X,Y,[X]).

osiagalny(X,Y,L):-
	arc(X,Z),
	\+member(Z,L),
	(
	      Y=Z;
	      osiagalny(Z,Y,[X|L])
	).




