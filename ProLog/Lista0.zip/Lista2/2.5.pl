lista(N,X):-generujliczby(Y,N),generujliste(X,Y).

generujliczby(X,N):-generujliczby(X,N,0,[]).
generujliczby(X,N,P,T):-
	(\+ P>N,W is P+1, generujliczby(X,N,W,[W|T]));
	(N=P,T=X).

generujliste(X,N):- generujliste(X,0,N,[],[],[]).
generujliste(X,_,[],[],[],T):- X=T.
generujliste(X,I,N,S0,S1,T):-
	((I=0,dodajstary0(X,N,S0,S1,T));
	 (I=1,dodajstary1(X,N,S0,S1,T)));
	dodajnowy(X,I,N,S0,S1,T).

dodajnowy(X,I,[N1|N2],S0,S1,T):-
	(I = 0, generujliste(X,1,N2,[N1|S0], S1    ,[N1|T]));
	(I = 1, generujliste(X,0,N2, S0    ,[N1|S1],[N1|T])).

dodajstary0(X,N,S0,S1,T):-
	elementlisty(S1,S2,S1,M),
	generujliste(X,1,N,S0,S2,[M|T]).

dodajstary1(X,N,S0,S1,T):-
	elementlisty(S0,S2,S0,M),
	generujliste(X,0,N,S2,S1,[M|T]).

elementlisty(S1,S2,[T1|T2],N):-
	(N=T1,select(T1,S1,S2));
	elementlisty(S1,S2,T2,N).


