ma(kamaz, programy).
ma(kamil, komputer).
ma(sikorski, ocene).

czas(0,1).
czas(1,2).
czas(2,3).
czas(3,4).
czas(4,5).

daje(1, kamaz, programy, kamil).
daje(1, kamil, komputer, kamil).
daje(2, sikorski, ocene, kamil).

czasy(X,X).
czasy(X,Y):-czas(X,Z),czasy(Z,Y).

ma(Kiedy, Kto, Co):-
	czasy(X,Kiedy),((X=0,ma(Kto,Co));(czas(_,X),daje(X,_,Co,Kto))),
	\+ (czasy(Y,Kiedy),Y>X,daje(Y,Kto,Co,_)).


	/*
,czasy(X,Y),X\=Y
*/
