%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%	HTTP client
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(http/http_open)).
:- use_module(library(xpath)).

ex1 :-
	http_open('http://cs.pwr.edu.pl/', In, []),
	copy_stream_data(In, user_output),
	close(In).

ex2(URL) :-
	http_open('http://cs.pwr.edu.pl/', In, []),
	load_html(In, DOM, []),
	close(In),
	xpath(DOM, //a(@href), URL).

