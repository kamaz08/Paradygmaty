:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/http_client)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_files)).

:- use_module(form).
:- use_module(queens).

:- http_handler(root(queens), handler_queens, []).
:- http_handler(root(solution), handler_solution, []).
:- http_handler(root(.), http_reply_from_files('pic', []), [prefix]).

% server(+Port) uruchomienie serwera na danym porcie
%
server(Port) :-
	http_server(http_dispatch, [port(Port)]).

handler_queens(_Request) :-
	format('Content-type: text/html~n~n'),
	format('<!DOCTYPE html><html><head><title>Queens Problem</title>~n', []),
	format('<meta http-equiv="content-type" content="text/html; charset=UTF-8">~n', []),
	format('</head><body>~n<h1>Gimme size of the problem</h1><br>~n', []),
	build_form([action(solution), method(post)],
		   [	label(rozmiar, 'Rozmiar'), input(text, size), br, input(submit)]),
	format('</body></html>~n', []).

%stworz przycisk
handler_solution(Request) :-
	member(method(post), Request),!,
	http_read_data(Request, Data, []),
	data(Data,X),
	reply_html_page(title('Solution Queens Problem'),h1('Solution'),table(\rozwiazanie(X))).

%	DOPISZ KOD OBSLUGUJACY USLUGE SOLUTION.
%
%DOPISZ REGULY GRAMATYKI METAMORFICZNEJ DO WYGENEROWANIA HTML.

data([_=Value | _],Value).
rozwiazanie(X) --> {atom_number(X,Y),Y =<100,Y>3,!, queens(Y,L)}, html(\linie(L,Y)).
rozwiazanie(X) --> html(p([X,' Nie jest liczba lub nie jest z przedzialu [4-100]'])),!.
linie([X|Rest],S) --> html(tr(\linia(1,X,S))), linie(Rest,S).
linie([],_) --> [].
linia(X,Y,S) --> {X=<S, (X=:=Y ->Z='src=\'queen.png\''; Z='src=\'empty.png\'')}, html(td(img(Z))), linia(X+1,Y,S).
linia(X,_,S) --> {X>S}, [].

