my_merge(IN1,IN2,OUT):-
	freeze(IN1,freeze(IN2,

	       (   (IN1=[L|TA],IN2=[R|T2])->
		 ((mniejsze(L,R)->
		    OUT=[L|RR],my_merge(TA,IN2,RR);
		   (OUT=[R|RR],my_merge(IN1,T2,RR))));
	           (IN1=[L|TA],OUT=[L|RR],my_merge(TA,IN2,RR),!);
	           (IN2=[R|T2],OUT=[R|RR],my_merge(IN1,T2,RR),!);
	            OUT=[]
	       ))).

my_split(IN, OUT1, OUT2):-
	freeze(IN, (
		         IN=[L,R|Rest]->
		        (OUT1=[L|O1],
			 freeze(R,(my_split(Rest, O1, O2), OUT2=[R|O2])));
		        (IN=[L|Rest]->OUT1=[L],OUT2=[]; (OUT1=[],OUT2=[]))
	           )
	      ).

merge_sort(X,L):-
	freeze(X, ( X \= [_] ->(
			  my_split(X,OUT1,OUT2),
			  merge_sort(OUT1,T),
			  merge_sort(OUT2,K),
			  my_merge(T,K,L));
		     L=X)).

mniejsze(X,Y):-
	number(X),number(Y),!,
	X<Y.

mniejsze(X,_):-
	number(X),!.
mniejsze(_,X):-
	number(X),!,false.

mniejsze(X,Y):-
	atom_chars(X,X2),atom_chars(Y,Y2),
	mniejszeString(X2,Y2).

mniejszeString([],_).
mniejszeString(_,[]):-false.
mniejszeString([S|X],[S|Y]):-
	mniejszeString(X,Y),!.
mniejszeString([X|_],[Y|_]):-
	char_code(X,X2),char_code(Y,Y2), X2<Y2.
