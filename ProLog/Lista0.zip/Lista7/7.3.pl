podnies_prawy_widelec(ID) :-
	PRAWY is (ID + 1) mod 5,
	atom_concat('widelec', PRAWY, WIDELEC),
	mutex_lock(WIDELEC),
	napisz(ID, 'podniosl prawy widelec').

podnies_lewy_widelec(ID) :-
	atom_concat('widelec', ID, WIDELEC),
	mutex_lock(WIDELEC),
	napisz(ID, 'podniosl lewy widelec').

odloz_prawy_widelec(ID) :-
	PRAWY is (ID + 1) mod 5,
	atom_concat('widelec', PRAWY, WIDELEC),
	napisz(ID, 'odlozyl prawy widelec'),
	mutex_unlock(WIDELEC).

odloz_lewy_widelec(ID) :-
	atom_concat('widelec', ID, WIDELEC),
	napisz(ID, 'odlozyl lewy widelec'),
	mutex_unlock(WIDELEC).

jedz(ID) :-
	napisz(ID, 'je'),
	sleep(2).


filozof(ID, 0) :- napisz(ID, 'zjadl wszystko').
filozof(ID, ILE) :-
	napisz(ID, 'mysli'),
	mutex_lock(sprawdz_mutex),
	napisz(ID, 'chce prawy widelec'),
	podnies_prawy_widelec(ID),
	napisz(ID, 'chce lewy widelec'),
	podnies_lewy_widelec(ID),
	mutex_unlock(sprawdz_mutex),
	jedz(ID),
	odloz_prawy_widelec(ID),
	odloz_lewy_widelec(ID),
	I is ILE - 1,
	filozof(ID, I).

zrob_odstep(0).
zrob_odstep(ID) :-
	write('    '),
	I is ID - 1,
	zrob_odstep(I).

napisz(ID, NAPIS) :-
	mutex_lock(napis_mutex),
	zrob_odstep(ID),
	write('['),write(ID), write(']   '), writeln(NAPIS),
	mutex_unlock(napis_mutex),
	sleep(1).

filozofowie :-
	ILE is 3,
	thread_create(filozof(0, ILE), _, []),
	thread_create(filozof(1, ILE), _, []),
	thread_create(filozof(2, ILE), _, []),
	thread_create(filozof(3, ILE), _, []),
	thread_create(filozof(4, ILE), _, []).

